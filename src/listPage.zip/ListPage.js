import React, { Component } from "react";

const example = {
  background: "red",
  height: "30vh",
};

class ListPage extends Component {
  render() {
    return <div style={example}>List Page</div>;
  }
}

export default ListPage;
